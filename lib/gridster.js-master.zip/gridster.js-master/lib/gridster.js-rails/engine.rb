module Gridster
  module Rails
    class Engine < ::Rails::Engine
    end
  end
end
