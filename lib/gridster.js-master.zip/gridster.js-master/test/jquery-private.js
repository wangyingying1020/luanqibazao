define(['jquery'], function (jq) {
	'use strict';
    return jq.noConflict( true );
});
